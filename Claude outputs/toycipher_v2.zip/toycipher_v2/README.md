# ToyCipher v2 (hardened)

Security rework of the original ToyCipher. See REPORT.md for the full analysis.

## What's here
- `toycipher/`         the hardened cipher package (drop-in API)
- `REPORT.md`          vulnerabilities found, fixes, and cryptanalysis (start here)
- `pipeline_tests.py`  correctness + tamper + downgrade tests for the message layer
- `analysis_harness.py` old-vs-new comparison (branch number, diffusion, avalanche);
                        expects the ORIGINAL package importable as `toycipher` to compare against

## Use
```python
from toycipher.modes import encrypt_message, decrypt_message
blob = encrypt_message(b"secret", "password")
print(decrypt_message(blob, "password"))
```

## Headline changes vs v1
1. Diffusion layer: bit-permutation P-box  ->  ShiftRows + MDS MixColumns (branch number 2 -> 5)
2. Password KDF: PBKDF2  ->  memory-hard scrypt (GPU-hostile)
3. Authenticated, versioned blob header (blocks downgrade attacks)

NOTE: v2 blobs are NOT compatible with v1 blobs (different KDF + format).
