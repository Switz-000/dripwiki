import sys, os, time
sys.path.insert(0,"/home/claude")
from tc2.modes import encrypt_message, decrypt_message, DecryptionError

print("MESSAGE PIPELINE CORRECTNESS")
ok=0; tot=0
def t(name, cond):
    global ok,tot; tot+=1; ok+=cond
    print(f"  [{'PASS' if cond else 'FAIL'}] {name}")

msg=b"meet me at the docks at midnight"
blob=encrypt_message(msg,"casio135")
t("round trip recovers message", decrypt_message(blob,"casio135")==msg)
try: decrypt_message(blob,"wrong"); t("wrong password rejected",False)
except DecryptionError: t("wrong password rejected",True)
bad=bytearray(blob); bad[40]^=1
try: decrypt_message(bytes(bad),"casio135"); t("ciphertext tamper detected",False)
except DecryptionError: t("ciphertext tamper detected",True)
# DOWNGRADE ATTACK: flip the log2(N) byte in the header (offset 4)
dg=bytearray(blob); dg[4]=1  # try to force N=2 (trivial KDF)
try: decrypt_message(bytes(dg),"casio135"); t("header DOWNGRADE attack blocked",False)
except DecryptionError: t("header DOWNGRADE attack blocked",True)
for L in (0,1,15,16,17,100):
    m=os.urandom(L); t(f"len={L} round trips", decrypt_message(encrypt_message(m,"pw"),"pw")==m)
t("same msg twice looks different", encrypt_message(msg,"pw")!=encrypt_message(msg,"pw"))
print(f"  => {ok}/{tot} passed")

print("\nKDF COST (defender pays once; attacker pays per guess)")
n=5; s=time.time()
for i in range(n): encrypt_message(b"x", f"p{i}")
dt=(time.time()-s)/n
print(f"  scrypt N=2^15,r=8: ~{dt*1000:.0f} ms per derive, ~32 MB RAM each")
print(f"  attacker single-core rate now: ~{1/dt:.1f} guesses/sec (was PBKDF2 ~31/s CPU, ~30k/s per GPU)")
print(f"  KEY POINT: scrypt's 32MB/guess starves GPUs (little fast shared RAM),")
print(f"             collapsing the attacker's cheap parallelism advantage.")
