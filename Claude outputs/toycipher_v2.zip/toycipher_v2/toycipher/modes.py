"""
Message layer: versioned, authenticated, CBC + Encrypt-then-MAC.

UPGRADES over the original:
  * A VERSION + KDF-parameter HEADER is prepended, so we can raise the cost
    later without silently breaking old ciphertexts.
  * The MAC now covers the HEADER too. Without this, an attacker could edit the
    header to say "use weak KDF settings" (a downgrade attack). Authenticating
    the header makes any such tampering fail closed.
Everything good about the original is kept: fresh random salt+IV per message,
verify-before-unpad (kills padding oracles), constant-time tag compare.
"""
import hmac, hashlib, secrets, struct
from .spncipher import encrypt_block, decrypt_block, BLOCK_SIZE
from .kdf import derive_keys, SALT_SIZE, SCRYPT_N, SCRYPT_R, SCRYPT_P

IV_SIZE = 16
TAG_SIZE = 32
VERSION = 2
MAGIC = b"TC2"


class DecryptionError(Exception):
    pass


def _header():
    # magic(3) | version(1) | log2(N)(1) | r(2) | p(2)
    return MAGIC + struct.pack(">BBHH", VERSION, SCRYPT_N.bit_length() - 1, SCRYPT_R, SCRYPT_P)


def _parse_header(blob):
    if blob[:3] != MAGIC:
        raise DecryptionError("bad magic / not a TC2 blob")
    ver, logn, r, p = struct.unpack(">BBHH", blob[3:9])
    if ver != VERSION:
        raise DecryptionError(f"unsupported version {ver}")
    return (1 << logn), r, p, blob[:9]


def pkcs7_pad(data, bs=BLOCK_SIZE):
    pad = bs - (len(data) % bs)
    return data + bytes([pad]) * pad


def pkcs7_unpad(data, bs=BLOCK_SIZE):
    if not data or len(data) % bs != 0:
        raise DecryptionError("corrupted padding")
    pad = data[-1]
    if pad == 0 or pad > bs or data[-pad:] != bytes([pad]) * pad:
        raise DecryptionError("corrupted padding")
    return data[:-pad]


def _cbc_encrypt(pt, key, iv):
    out, prev = b"", iv
    for i in range(0, len(pt), BLOCK_SIZE):
        prev = encrypt_block(bytes(a ^ b for a, b in zip(pt[i:i+BLOCK_SIZE], prev)), key)
        out += prev
    return out


def _cbc_decrypt(ct, key, iv):
    out, prev = b"", iv
    for i in range(0, len(ct), BLOCK_SIZE):
        blk = ct[i:i+BLOCK_SIZE]
        out += bytes(a ^ b for a, b in zip(decrypt_block(blk, key), prev))
        prev = blk
    return out


def encrypt_message(plaintext: bytes, password: str) -> bytes:
    header = _header()
    salt, iv = secrets.token_bytes(SALT_SIZE), secrets.token_bytes(IV_SIZE)
    enc_key, mac_key = derive_keys(password, salt)
    ct = _cbc_encrypt(pkcs7_pad(plaintext), enc_key, iv)
    tag = hmac.new(mac_key, header + salt + iv + ct, hashlib.sha256).digest()
    return header + salt + iv + ct + tag


def decrypt_message(blob: bytes, password: str) -> bytes:
    if len(blob) < 9 + SALT_SIZE + IV_SIZE + TAG_SIZE + BLOCK_SIZE:
        raise DecryptionError("data too short")
    n, r, p, header = _parse_header(blob)
    body = blob[9:]
    salt = body[:SALT_SIZE]
    iv = body[SALT_SIZE:SALT_SIZE+IV_SIZE]
    tag = body[-TAG_SIZE:]
    ct = body[SALT_SIZE+IV_SIZE:-TAG_SIZE]
    if len(ct) == 0 or len(ct) % BLOCK_SIZE != 0:
        raise DecryptionError("corrupted ciphertext length")
    enc_key, mac_key = derive_keys(password, salt, n=n, r=r, p=p)
    expected = hmac.new(mac_key, header + salt + iv + ct, hashlib.sha256).digest()
    if not hmac.compare_digest(tag, expected):
        raise DecryptionError("wrong password or tampered data")
    return pkcs7_unpad(_cbc_decrypt(ct, enc_key, iv))
