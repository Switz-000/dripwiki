"""
SPN core, unchanged in shape from the original, but the round's diffusion step
is now ShiftRows+MixColumns (diffusion.py) instead of the old bit P-box.

Rounds 1..9:  SubBytes -> ShiftRows -> MixColumns -> AddRoundKey
Round 10   :  SubBytes ->                            AddRoundKey   (no MixColumns)
Round 0    :  AddRoundKey (initial whitening)
"""
from .sbox import SBOX, INV_SBOX
from .diffusion import permute, inverse_permute
from .keyschedule import expand_key, NUM_ROUNDS

BLOCK_SIZE = 16


def _xor(a, b): return bytes(x ^ y for x, y in zip(a, b))
def _sub_bytes(b): return bytes(SBOX[x] for x in b)
def _inv_sub_bytes(b): return bytes(INV_SBOX[x] for x in b)


def encrypt_block(plaintext: bytes, key: bytes) -> bytes:
    if len(plaintext) != BLOCK_SIZE:
        raise ValueError("block must be 16 bytes")
    rk = expand_key(key)
    state = _xor(plaintext, rk[0])
    for r in range(1, NUM_ROUNDS):
        state = permute(_sub_bytes(state))
        state = _xor(state, rk[r])
    state = _xor(_sub_bytes(state), rk[NUM_ROUNDS])
    return state


def decrypt_block(ciphertext: bytes, key: bytes) -> bytes:
    if len(ciphertext) != BLOCK_SIZE:
        raise ValueError("block must be 16 bytes")
    rk = expand_key(key)
    state = _xor(ciphertext, rk[NUM_ROUNDS])
    state = _inv_sub_bytes(state)
    for r in range(NUM_ROUNDS - 1, 0, -1):
        state = _xor(state, rk[r])
        state = inverse_permute(state)
        state = _inv_sub_bytes(state)
    state = _xor(state, rk[0])
    return state


def _self_check():
    import os
    for _ in range(200):
        k, pt = os.urandom(16), os.urandom(16)
        assert decrypt_block(encrypt_block(pt, k), k) == pt


_self_check()
