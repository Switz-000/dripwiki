"""
Galois Field GF(2^8) arithmetic.

This is the mathematical machinery behind our S-box. We deliberately use a
DIFFERENT irreducible polynomial than AES (which uses 0x11B), so our field -
and therefore our S-box - isn't just a re-skin of AES's.

If you haven't seen a "finite field" before: think of GF(2^8) as a version of
arithmetic on bytes where addition is XOR (no carrying) and multiplication
"wraps around" using a fixed rule (the modulus polynomial) whenever a result
would need a 9th bit. Every one of the 255 non-zero bytes has a unique
multiplicative inverse, just like every non-zero real number does.
"""

# x^8 + x^4 + x^3 + x^2 + 1 -- a different (but equally valid) irreducible
# polynomial over GF(2) than the one AES uses (0x11B).
MODULUS = 0x11D


def gf_mult(a: int, b: int, modulus: int = MODULUS) -> int:
    """Multiply two bytes as elements of GF(2^8) (Russian-peasant multiplication)."""
    a &= 0xFF
    b &= 0xFF
    result = 0
    for _ in range(8):
        if b & 1:
            result ^= a
        carry = a & 0x80
        a = (a << 1) & 0xFF
        if carry:
            a ^= (modulus & 0xFF)
        b >>= 1
    return result & 0xFF


def gf_inverse(a: int) -> int:
    """
    Multiplicative inverse of `a` in GF(2^8).

    0 has no real inverse in any field; by the same convention AES uses,
    we just define inverse(0) = 0 so the S-box stays a full 256-entry table.
    The field only has 256 elements, so brute force is instant and avoids
    any chance of an extended-Euclid bug.
    """
    if a == 0:
        return 0
    for candidate in range(1, 256):
        if gf_mult(a, candidate) == 1:
            return candidate
    raise ValueError("no inverse found -- MODULUS is not irreducible!")


def xtime(a: int) -> int:
    """Multiply by the polynomial 'x' (i.e. by 2) in our GF(2^8)."""
    return gf_mult(a, 0x02)


def _self_check():
    # Every non-zero element must have an inverse that multiplies back to 1.
    for a in range(1, 256):
        assert gf_mult(a, gf_inverse(a)) == 1, f"bad inverse for {a}"


_self_check()
