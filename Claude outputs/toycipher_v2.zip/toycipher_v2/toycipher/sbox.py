"""
Builds our custom 8-bit S-box -- the "confusion" layer of the cipher.

Construction (same philosophy AES uses, different numbers):
  1. Take the multiplicative inverse of the byte in OUR GF(2^8) (gf.py).
     Inversion is a highly non-linear operation on a finite field -- it's
     the main reason AES-style S-boxes resist linear and differential
     cryptanalysis so well (the best "differential" you can find through
     an inverse map is 4/256, versus 256/256 for something linear).
  2. Run the result through a custom, invertible affine transformation
     (a bit-mixing step, then XOR a fixed constant) to destroy the clean
     algebraic structure that inversion alone leaves behind. Without this
     step, inverse(0) = 0 and inverse(1) = 1 would give an attacker two
     free "fixed points" to exploit.
"""
from .gf import gf_inverse

# Custom choices -- different from AES's rotations (1,2,3,4) and
# constant (0x63). Verified invertible in sandbox before being hardcoded here.
AFFINE_ROTATIONS = (1, 3, 5, 7)
AFFINE_CONSTANT = 0x5B


def _rotl8(b: int, n: int) -> int:
    n %= 8
    return ((b << n) | (b >> (8 - n))) & 0xFF


def _affine(b: int) -> int:
    out = b
    for r in AFFINE_ROTATIONS:
        out ^= _rotl8(b, r)
    return out ^ AFFINE_CONSTANT


def _affine_is_invertible() -> bool:
    """The linear part of the affine map must be a bijection on GF(2)^8,
    or the S-box we build from it won't be a valid (invertible) permutation."""
    seen = {_affine(b) ^ AFFINE_CONSTANT for b in range(256)}
    return len(seen) == 256


assert _affine_is_invertible(), "affine transform is not invertible -- pick different rotations"


def build_sbox():
    sbox = [_affine(gf_inverse(b)) for b in range(256)]
    assert sorted(sbox) == list(range(256)), "S-box is not a valid permutation!"
    return sbox


def build_inverse_sbox(sbox):
    inv = [0] * 256
    for i, v in enumerate(sbox):
        inv[v] = i
    return inv


SBOX = build_sbox()
INV_SBOX = build_inverse_sbox(SBOX)


def _self_check():
    for b in range(256):
        assert INV_SBOX[SBOX[b]] == b


_self_check()
