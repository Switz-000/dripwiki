"""
Password -> (encryption key, MAC key).

UPGRADE over the original: switched from PBKDF2 to scrypt. PBKDF2 is fast on
GPUs, which is exactly what a password cracker uses. scrypt is *memory-hard*:
it forces the attacker to spend a big chunk of RAM per guess, and GPUs have
lots of cores but comparatively little fast memory to share among them. So the
attacker's cheap massive parallelism stops being cheap. Same password, same
security model, but every guess now costs the attacker real money.

Parameters (tunable): N=2**15, r=8, p=1  -> ~32 MB and ~50-100 ms per derive
on a normal machine. Barely noticeable to the user, painful to a cracker farm.
"""
import hashlib

SCRYPT_N = 2 ** 15   # CPU/memory cost
SCRYPT_R = 8
SCRYPT_P = 1
SALT_SIZE = 16
DERIVED_SIZE = 32    # -> two 16-byte keys


def derive_keys(password: str, salt: bytes,
                n: int = SCRYPT_N, r: int = SCRYPT_R, p: int = SCRYPT_P):
    if len(salt) != SALT_SIZE:
        raise ValueError(f"salt must be {SALT_SIZE} bytes")
    # OpenSSL needs an explicit memory ceiling >= 128*N*r bytes for scrypt.
    maxmem = 128 * n * r + (1 << 20)
    master = hashlib.scrypt(
        password.encode("utf-8"), salt=salt,
        n=n, r=r, p=p, dklen=DERIVED_SIZE, maxmem=maxmem
    )
    return master[:16], master[16:]
