"""
Wide-trail diffusion layer: ShiftRows + MixColumns (replaces the old bit P-box).

Why this exists: the old P-box just MOVED bits around. Moving one bit gives you
one bit back, so a single-bit difference could slip through every round touching
only ONE S-box per round. That is the hole that dropped the real security from
128 bits to ~63. This layer MIXES bytes instead of moving bits, so a change to
one byte is forced to infect several bytes in the very next round.

State layout (AES convention): 16 bytes as a 4x4 grid, column-major.
  byte index = 4*col + row  ->  element (row, col)
"""
from .gf import gf_mult, MODULUS

# 4x4 circulant MDS matrix over GF(2^8). Same shape AES uses; we verify below
# that it is genuinely MDS (branch number 5) in OUR field (modulus 0x11D).
M = [[2, 3, 1, 1],
     [1, 2, 3, 1],
     [1, 1, 2, 3],
     [3, 1, 1, 2]]


def _gf_det(mat):
    """Determinant of a square matrix over GF(2^8) via elimination."""
    n = len(mat)
    m = [row[:] for row in mat]
    det = 1
    for col in range(n):
        piv = next((r for r in range(col, n) if m[r][col] != 0), None)
        if piv is None:
            return 0
        if piv != col:
            m[col], m[piv] = m[piv], m[col]
        det = gf_mult(det, m[col][col])
        inv = _gf_inv(m[col][col])
        for r in range(col + 1, n):
            if m[r][col]:
                f = gf_mult(m[r][col], inv)
                m[r] = [a ^ gf_mult(f, b) for a, b in zip(m[r], m[col])]
    return det


def _gf_inv(a):
    if a == 0:
        return 0
    for c in range(1, 256):
        if gf_mult(a, c) == 1:
            return c
    raise ValueError("no inverse")


def _submatrices_all_invertible(mat):
    """MDS <=> every square submatrix is non-singular <=> branch number = 5."""
    from itertools import combinations
    n = len(mat)
    for k in range(1, n + 1):
        for rows in combinations(range(n), k):
            for cols in combinations(range(n), k):
                sub = [[mat[r][c] for c in cols] for r in rows]
                if _gf_det(sub) == 0:
                    return False
    return True


def _matrix_inverse(mat):
    """Inverse of a 4x4 matrix over GF(2^8) (Gauss-Jordan)."""
    n = len(mat)
    a = [mat[r][:] + [1 if i == r else 0 for i in range(n)] for r in range(n)]
    for col in range(n):
        piv = next(r for r in range(col, n) if a[r][col] != 0)
        a[col], a[piv] = a[piv], a[col]
        inv = _gf_inv(a[col][col])
        a[col] = [gf_mult(inv, x) for x in a[col]]
        for r in range(n):
            if r != col and a[r][col]:
                f = a[r][col]
                a[r] = [x ^ gf_mult(f, y) for x, y in zip(a[r], a[col])]
    return [row[n:] for row in a]


assert _submatrices_all_invertible(M), "MixColumns matrix is NOT MDS in this field!"
MINV = _matrix_inverse(M)


def _mix_one_column(col, mat):
    return bytes(
        gf_mult(mat[r][0], col[0]) ^ gf_mult(mat[r][1], col[1]) ^
        gf_mult(mat[r][2], col[2]) ^ gf_mult(mat[r][3], col[3])
        for r in range(4)
    )


def _mix_columns(block, mat):
    out = bytearray(16)
    for c in range(4):
        col = block[4 * c:4 * c + 4]
        out[4 * c:4 * c + 4] = _mix_one_column(col, mat)
    return bytes(out)


def _shift_rows(block, inverse=False):
    out = bytearray(16)
    for r in range(4):
        for c in range(4):
            src = (c + r) % 4 if not inverse else (c - r) % 4
            out[4 * c + r] = block[4 * src + r]
    return bytes(out)


def permute(block: bytes) -> bytes:
    if len(block) != 16:
        raise ValueError("permute() expects a 16-byte block")
    return _mix_columns(_shift_rows(block), M)


def inverse_permute(block: bytes) -> bytes:
    if len(block) != 16:
        raise ValueError("inverse_permute() expects a 16-byte block")
    return _shift_rows(_mix_columns(block, MINV), inverse=True)


def branch_number():
    """Empirical branch number of MixColumns: min(wt_in + wt_out) over one column."""
    best = 99
    for a in range(256):
        for b in range(256):
            for pos in range(4):
                col = [0, 0, 0, 0]
                col[pos] = a
                if b:  # two-active-byte inputs too (covers weight 1 and 2)
                    col[(pos + 1) % 4] = b
                if not any(col):
                    continue
                out = _mix_one_column(bytes(col), M)
                w = sum(1 for x in col if x) + sum(1 for x in out if x)
                best = min(best, w)
    return best


def _self_check():
    import os
    for _ in range(300):
        blk = os.urandom(16)
        assert inverse_permute(permute(blk)) == blk, "diffusion not invertible"


_self_check()
